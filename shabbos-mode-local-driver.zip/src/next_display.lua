-- Presentation only. No scheduling timers or changes to the calendar engine.
local data = require "timezone_data"
local M = {}
local months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}
local weekdays = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}

function M.offset(timestamp, name)
  -- Map API-safe preference keys (America_New_York) to IANA zone names.
  local zone = data.zones[name]
  if not zone then
    for zone_name, rows in pairs(data.zones) do
      if zone_name:gsub("/", "_") == name then zone = rows; break end
    end
  end
  assert(zone, "Unsupported display timezone: " .. tostring(name))
  local lo, hi = 1, #zone
  while lo < hi do
    local mid = math.ceil((lo + hi) / 2)
    if zone[mid][1] <= timestamp then lo = mid else hi = mid - 1 end
  end
  return zone[lo][2], zone[lo][3]
end

function M.format_time(timestamp, name)
  local offset, abbreviation = M.offset(timestamp, name)
  local d = os.date("!*t", timestamp + offset)
  local hour = d.hour % 12
  if hour == 0 then hour = 12 end
  local meridiem = d.hour < 12 and "AM" or "PM"
  return string.format("%s %s %d, %d at %d:%02d %s %s", weekdays[d.wday],
    months[d.month], d.day, d.year, hour, d.min, meridiem, abbreviation)
end

local function first_event(now, settings, expected, next_event, manual)
  if settings.enabled and manual and manual.expires > now
    and manual.expires < next_event.at and manual.state ~= expected then
    return { state = expected, at = manual.expires, override_end = true }
  end
  return next_event
end

function M.values(now, settings, expected, next_event, manual, preferences)
  local zone = (preferences or {}).displayTimezone or "America/New_York"
  local event = first_event(now, settings, expected, next_event, manual)
  local status = "Automatic schedule active"
  if not settings.enabled then
    status = "Automatic scheduling OFF; next time is a preview only"
  elseif manual then
    status = "Manual override until " .. M.format_time(manual.expires, zone)
  end
  local label = event.state:upper() .. " - " .. M.format_time(event.at, zone)
  if not settings.enabled then label = "Preview: " .. label
  elseif event.override_end then label = label .. " (override ends)" end
  return label, status
end

local function compact_event(event, zone, enabled)
  if not event then return "Later event", "--" end
  local offset = M.offset(event.at, zone)
  local d = os.date("!*t", event.at + offset)
  local hour = d.hour % 12
  if hour == 0 then hour = 12 end
  local heading = string.format("%s %02d/%02d", event.state:upper(), d.month, d.day)
  if not enabled then heading = "~" .. heading
  elseif event.override_end then heading = "*" .. heading end
  local time = string.format("%d:%02d %s", hour, d.min, d.hour < 12 and "AM" or "PM")
  return heading, time
end

function M.compact_values(now, settings, expected, next_event, following_event, manual, preferences)
  local zone = (preferences or {}).displayTimezone or "America/New_York"
  local first = first_event(now, settings, expected, next_event, manual)
  -- Returning from an opposite manual hold is followed by the next natural event.
  local second = first.override_end and next_event or following_event
  local a, b = compact_event(first, zone, settings.enabled)
  local c, d = compact_event(second, zone, settings.enabled)
  return { nextLabel = a .. "\n" .. b, nextTime = b,
    followingLabel = c .. "\n" .. d, followingTime = d }
end

return M
