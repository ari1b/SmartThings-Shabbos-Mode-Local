-- Register the capability and replace this placeholder with Setup-Display.ps1.
-- Ordinary shared-channel users do not run that setup script.
return { capability_id = "beachghost18507.shabbosNextEvents" }
